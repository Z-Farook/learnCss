import { Button, Grid } from "@material-ui/core";
import { useAlbums } from "../hooks/useAlbum";
import { AlbumCard } from "./AlbumCard";
import { Fragment } from 'react';

export function AlbumOverview() {
    const albums = useAlbums();
    console.log("process.env.REACT_APP_API_URL + '/api/albums'");
    const dummydata = [
        {
            id: 1,
            title: 'Album 1',
            artist: 'Artist 1'
        },
        {
            id: 2,
            title: 'Album 2',
            artist: 'Artist 2'
        },
        {
            id: 3,
            title: 'Album 3',
            artist: 'Artist 4'
        },
        {
            id: 4,
            title: 'Album 4',
            artist: 'Artist 4'
        }
    ];
    if (!albums) {
        return (
            <Fragment />
        )
    }
    return (
        <Grid container spacing={3}>
            {/* using the dummy array: dummydata we need to replace it real api cal data! */}
            {dummydata.map(album => (
                <Grid item key={album.id}>
                    <AlbumCard title={album.title} artist={album.artist} />
                </Grid>
            ))}
            <Grid item key={"new"}>
                <Button size="large" variant={"contained"} color="primary">
                    Add
                </Button>
            </Grid>
        </Grid>
    );
}
