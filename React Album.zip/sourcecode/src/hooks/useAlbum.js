import { useState, useEffect } from 'react';


export function useAlbums() {
    const [album, setAlbum] = useState(null);
    const uri = process.env.REACT_APP_API_URL + 'api/Albums'
    const handleFetch = () => {
        fetch(uri)
            .then(response => response.json())
            .then(data => setAlbum(data))
    }
    console.log(album)
    useEffect(() => {
        handleFetch();
    }, []);

    return album;
}
