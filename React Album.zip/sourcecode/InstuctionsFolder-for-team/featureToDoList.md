# THE EXPECTED CRUD FEATURES:

- An overview of all albums (this is mostly already done see component folder)
- A detail page for an album
- The ability to add albums
- The ability to customize albums
- The ability to delete albums

All of the page needs to functionally correct! What can be omitted: testing Typescript

## Use the following libraries for this:

- react-router-dom for routing.
- Documentation: https://reactrouter.com/web/
- react-hook-form for facilitating form creation.
- Documentation: https://react-hook-form.com/get-started
- @material-ui/core as a UI library to have a consistent basic interface.
- Documentation: https://material-ui.com/

---

## BASIC REACT APPLICATION

Run: npm install before starting the application
based on this source code. It will install all dependencies for the project!
Use a dummy back-end which has a table containing the columns:
{
id integer
name string
artist string
imageUrl string
}

### Create a useAlbums hook to get the data data: (already exists in the hooks folder)

- In .env file in the root directory of the application to add your own environment variable that contains the URL of the API ( use a dummy as you wish then i will change it).

- Then use the useAlbums hook in the AlbumOverview component to get your real albums from your API.
- Use the Fetch API for this
- Use React's built-in useState and useEffect hooks
- The custom environment variable must start with REACT*APP* and can be accessed in code with, for example, process.env. EACT_APP_API_URL.
